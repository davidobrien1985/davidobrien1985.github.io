﻿#region Functions
Function Save-Password
{
  Param
  (
    [parameter(Mandatory = $true)]
    [String]
    $FilePath,
    
    [parameter(Mandatory = $false)]
    [Switch]
    $PassThru
  )
  
  $secure = Read-Host -AsSecureString 'Enter your Azure organization ID password.'
  $encrypted = ConvertFrom-SecureString -SecureString $secure
  $result = Set-Content -Path $FilePath -Value $encrypted -PassThru
  
  if (!$result)
  {
    throw "Failed to store encrypted string at $FilePath."
  }
  if ($PassThru)
  {
    Get-ChildItem $FilePath
  }
}

#endregion Functions
#region connect to Azure
try {
  if (-not (Get-Module -Name Azure)) {
    $null = Import-Module -Name Azure
  }
} 
catch {
  Write-Error -Message {0} -f $PSItem;
}

$FilePath = Save-Password -FilePath 'C:\temp\Azure\Password.txt' -PassThru

$userName = 'automation@yourdomain.onmicrosoft.com'
$securePassword = ConvertTo-SecureString (Get-Content -Path $FilePath)
$cred = New-Object System.Management.Automation.PSCredential($userName, $securePassword)
$result = Add-AzureAccount -Credential $cred 
$result

$Subscription = Get-AzureSubscription | Out-GridView -OutputMode Single

Set-AzureSubscription -SubscriptionId $Subscription.SubscriptionId -Verbose

#endregion connect to Azure
#region create VM
$AffinityGroup = New-AzureAffinityGroup -Name 'GAB-DC' -Location 'Southeast Asia' -Verbose

# Storage accounts must be lower case and only letters and numbers
$StorageAccount = 'GAB-DC1'
$StorageAccountName = [Regex]::Replace($StorageAccount.ToLower(), '[^(a-z0-9)]', '')
$StorageAccount = New-AzureStorageAccount -StorageAccountName $StorageAccountName -AffinityGroup 'GAB-DC1' -Type 'Standard_LRS' -Description 'Storage Account for ADDS machine' -Verbose 


New-AzureService -ServiceName 'GAB-DC1-svc' -AffinityGroup 'GAB-DC' -Verbose

################## BREAK HERE!!! ###############

#Publish-AzureVMDscConfiguration -ConfigurationPath .\adds_configuration.ps1 -ConfigurationArchivePath C:\temp\Azure\adds_configuration.zip -Verbose -Force
Publish-AzureVMDscConfiguration -ConfigurationPath .\adds_configuration.ps1 -Verbose -Force

$AzureVMImage = Get-AzureVMImage | Where-Object { $_.ImageFamily -eq 'Windows Server 2012 R2 Datacenter' } | Sort-Object -Descending -Property PublishedDate | Out-GridView -OutputMode Single

$vm = New-AzureVMConfig -Name 'GAB-DC1' -InstanceSize Small -ImageName $AzureVMImage.ImageName  -Verbose

$vm = Add-AzureProvisioningConfig -VM $vm -Windows -AdminUsername 'david' -Password 'P@ssw0rd' -Verbose 

$vm = Add-AzureEndpoint -VM $vm -Name 'HTTP' -Protocol 'tcp' -PublicPort 80 -LocalPort 8080 

# Specify VNet Subnet for VM
$vm = Set-AzureSubnet -VM $vm -SubnetNames 'Subnet-1'

$vm = Set-AzureVMDSCExtension -VM $vm -ConfigurationArchive 'adds_configuration.ps1.zip' -ConfigurationName 'adds' -ConfigurationDataPath .\adds_configurationdata.psd1 -ConfigurationArgument @{ safemodeAdministratorCred = (Get-Credential -UserName '(Password Only)' -Message 'New Domain Safe Mode Administrator Password') ; domainCred = (Get-Credential -Message 'New Domain Admin Credentials')} -Verbose -Force

New-AzureVM -VM $vm -ServiceName 'GAB-DC1-svc' -VNetName 'testvnet' -WaitForBoot -Verbose -AffinityGroup 'GAB-DC'
#endregion create VM
#region Connect to VM

Get-AzureVMDscExtensionStatus -ServiceName gab-dc-svc -Name gab-dc -Verbose

$uri = Get-AzureWinRMUri -ServiceName gab-dc-svc -Name gab-dc -Verbose

InstallWinRMCert -serviceName gab-dc-svc -vmname gab-dc

Enter-PSSession -ConnectionUri $uri.AbsoluteUri -Credential $(Get-Credential -UserName localhost\adobrien -Message 'Type in Password') 

Get-DscConfigurationStatus

Set-Location C:\WindowsAzure\Logs\Plugins\Microsoft.Powershell.DSC\1.7.0.0\

Get-ADDomain

#endregion Connect to VM
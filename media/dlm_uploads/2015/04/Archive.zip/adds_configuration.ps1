﻿# A configuration to Create Domain Controller 
configuration ADDS
{
   param
    (
        [Parameter(Mandatory)]
        [pscredential]$safemodeAdministratorCred,
        [Parameter(Mandatory)]
        [pscredential]$domainCred
    )
    Import-DscResource -ModuleName xActiveDirectory
    Node $AllNodes.Where{$_.Role -eq 'Primary DC'}.Nodename
    {
        WindowsFeature DNS 
        {
            Ensure = 'Present'
            Name = 'DNS'
        }
        WindowsFeature DNSTools
        {
            Ensure = 'Present'
            Name = 'RSAT-DNS-Server'
            DependsOn = '[WindowsFeature]DNS'
        }

        WindowsFeature ADDSInstall
        {
            Ensure = 'Present'
            Name = 'AD-Domain-Services'
            DependsOn = '[WindowsFeature]DNSTools'
            
        }
        WindowsFeature ADDSTools
        {
            Ensure = 'Present'
            Name = 'RSAT-AD-Tools'
            DependsOn = '[WindowsFeature]ADDSInstall'
            IncludeAllSubFeature = $true
        }
        xADDomain FirstDS
        {
            DomainName = $Node.DomainName
            DomainAdministratorCredential = $domainCred
            SafemodeAdministratorPassword = $safemodeAdministratorCred
            DependsOn = '[WindowsFeature]ADDSInstall'
        }
    }
}
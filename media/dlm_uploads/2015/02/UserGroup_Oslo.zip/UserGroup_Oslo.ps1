﻿Import-Module (Join-Path $(Split-Path $env:SMS_ADMIN_UI_PATH) ConfigurationManager.psd1)


#region Show speed differences
Get-CMDevice -Name cm001
Measure-Command -Expression {Get-CMDevice -Name cm001}

Get-WmiObject -Class sms_r_system -Namespace root\sms\site_PS1 | Where-Object {$_.name –eq 'cm001'} 
Measure-Command -Expression {Get-WmiObject -Class sms_r_system -Namespace root\sms\site_PS1 -ComputerName CM001 | Where-Object {$_.name –eq 'cm001'}}

Get-WmiObject -Namespace root\sms\site_PRI -Query "SELECT * FROM SMS_r_system where name='cm12'"
Measure-Command -Expression {Get-WmiObject -Namespace root\sms\site_PS1 -ComputerName CM001 -Query "SELECT * FROM SMS_r_system where name='cm001'"}

Get-CMDevice –name cm12
Measure-Command -Expression {
Set-CMQueryResultMaximum -Maximum 3000 
Get-CMDevice | Where-Object {$_.name -eq 'cm001'}}
#endregion Show speed differences
#region Help yourselfLock-CMObject -InputObject $(Get-CMTaskSequence -Name 'OSD 1') -VerboseGet-CMTaskSequence -Name 'OSD 1' | Lock-CMObject # CU4Unlock-CMObject -InputObject $(Get-CMTaskSequence -Name 'OSD 1') -Verbose#endregion ####### How to create a folder#The old, WMI way:Function Create-CollectionFolder{	$FolderName = 'User Group Oslo'    if (-not (Get-WmiObject -Class SMS_ObjectContainerNode -Namespace root\sms\site_PS1 -Filter "ObjectType = '5000' and Name = '$($FolderName)'"))        {            Write-Output "$(Get-Date):   Folder does not exist, creating it."            $CollectionFolderArgs = @{	        Name = $FolderName;	        ObjectType = '5000'; 		# 5000 is for Collection_Device, 5001 is for Collection_User	        ParentContainerNodeid = "0" # ParentContainerNodeID is '0' if Folder underneath root folder, otherwise ParentContainerNodeID needs to be evaluated	        }	        Set-WmiInstance -Class SMS_ObjectContainerNode -arguments $CollectionFolderArgs -namespace 'root\SMS\Site_PS1' | Out-Null        }}

# The new way, in the PSDrive:
Set-Location '.\DeviceCollection'
New-Item -Path '.\Software Distribution' -ItemType Directory
New-Item -Path '.\Software Update Collections' -ItemType Directory
New-Item -Path '.\Operating System Deployment' -ItemType Directory
New-Item -Path '.\Settings Management' -ItemType Directory
New-Item -Path '.\AD Site Collections' -ItemType Directory
Set-Location -Path 'Operating System Deployment'
New-Item -Path '.\Servers' -ItemType Directory
New-Item -Path '.\Workstations' -ItemType Directory


#New in R2 CU4

Get-CMDevice -Name CM00* -DisableWildcardHandling -Verbose
Get-CMDevice -Name CM00* -ForceWildcardHandling -Verbose

Invoke-CMSystemDiscovery -SiteCode PS1 -Verbose
﻿
Function Get-SiteCode
{
    $wqlQuery = “SELECT * FROM SMS_ProviderLocation”
    $a = Get-WmiObject -Query $wqlQuery -Namespace “root\sms” #-ComputerName $SMSProvider
    $a | ForEach-Object {
        if($_.ProviderForLocalSite)
            {
                $script:SiteCode = $_.SiteCode
            }
    }
return $SiteCode
}

Function Import-CM12Module
{
#Import the CM12 Powershell cmdlets
if (-not (Test-Path -Path $SiteCode))
    {
        Write-Output "$(Get-Date):   CM12 module has not been imported yet, will import it now."
        Import-Module (Join-Path (Split-Path $env:SMS_ADMIN_UI_PATH -parent) ConfigurationManager.psd1) | Out-Null
    }

#CM12 cmdlets need to be run from the CM12 drive
Set-Location "$($SiteCode):" | Out-Null
if (-not (Get-PSDrive -Name $SiteCode))
    {
        Write-Error "There was a problem loading the Configuration Manager powershell module and accessing the site's PSDrive."
        exit 1
    }
}

Get-SiteCode
Import-CM12Module

$SiteDescription=@{}
$SitesDN="LDAP://CN=Sites," + $([adsi] "LDAP://RootDSE").Get("ConfigurationNamingContext")

foreach ($Site in $([adsi] $SitesDN).psbase.children)
    {
        if ($Site.objectClass -eq "site")
            {
                $Name = ([string]$Site.cn).toUpper()
                $SiteDescription[$Name] = $Site.Description
            }
    }


foreach ($ADSite in $SiteDescription.Keys)
    {
        Write-Output "$(Get-Date):   Creating Device Collection `"All Systems in AD Site $($ADSite)`""
        $Schedule = New-CMSchedule -RecurInterval Days -RecurCount 7
        $Coll = New-CMDeviceCollection -LimitingCollectionId SMS00001 -Name "All Systems in AD Site $($ADSite)" -RefreshSchedule $Schedule -Comment "All Systems in AD Site $($ADSite)"
        Add-CMDeviceCollectionQueryMembershipRule -CollectionId $Coll.CollectionID -RuleName "All Systems in AD Site $($ADSite)" -QueryExpression "SELECT SMS_R_System.Name, SMS_R_System.ADSiteName FROM SMS_R_System where SMS_R_System.ADSiteName = `"$ADSite`""
    }
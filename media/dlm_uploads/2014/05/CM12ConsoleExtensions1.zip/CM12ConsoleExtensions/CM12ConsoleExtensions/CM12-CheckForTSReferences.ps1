﻿param (
$Object = $args[0],
$SMSProvider= $args[1],
$SiteCode = $args[2]
)

Function Get-SiteCode
{
    $wqlQuery = “SELECT * FROM SMS_ProviderLocation”
    $a = Get-WmiObject -Query $wqlQuery -Namespace “root\sms” -ComputerName $SMSProvider
    $a | ForEach-Object {
        if($_.ProviderForLocalSite)
            {
                $script:SiteCode = $_.SiteCode
            }
    }
return $SiteCode
}
Get-SiteCode

$References = Get-CimInstance -ComputerName $SMSProvider -Namespace root\SMS\site_$SiteCode -Query "Select * FROM SMS_TaskSequencePackageReference WHERE ObjectID = '$Object' OR RefPackageID = '$Object'"   

$TaskSequences = @()
foreach ($Ref in $References)
    {
        $TS = Get-CimInstance -ComputerName $SMSProvider -Namespace root\SMS\Site_$SiteCode -Query "SELECT Name FROM SMS_TaskSequencePackage WHERE PackageID = '$($Ref.PackageID)'"
        $TaskSequences += $TS.Name
    }

if ([string]::IsNullOrEmpty($TaskSequences))
    {
        [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") | Out-Null
        [System.Windows.Forms.MessageBox]::Show("This object is not referenced in any Task Sequence.")
    }    
else
    {
        [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") | Out-Null
        [System.Windows.Forms.MessageBox]::Show("Referenced in the following Task Sequence(s): $(foreach ($TS in $TaskSequences){" `n $TS"})")
    }
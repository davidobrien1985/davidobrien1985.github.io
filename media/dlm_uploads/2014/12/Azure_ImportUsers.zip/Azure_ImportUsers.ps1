﻿[cmdletBinding()]
param (
[Parameter(Mandatory = $true)]
[string]$PathToCsv = 'C:\Users\David\OneDrive\Events\InfraSat2014\userdata.csv',
[Parameter(Mandatory = $true)]
[string]$AzureUserName = '',
[Parameter(ParameterSetName='SendMail')]
[switch]$SendMail,
[Parameter(ParameterSetName='SendMail')]
[string]$SmtpServer = 'smtp.live.com',
[Parameter(ParameterSetName='SendMail')]
[string]$EmailUser = '',
[Parameter(ParameterSetName='SendMail')]
[string]$EmailPasswordEncrypted = ''
)

#requires -Version 4
#requires -Module MSOnline
$PSDefaultParameterValues = @{'*:Verbose'=$True}
Set-StrictMode -Version 3

#region declare variables

#endregion declare variables

#region Functions
Function Save-Password
{
  Param
  (
    [parameter(Mandatory = $true)]
    [String]
    $FilePath,
    
    [parameter(Mandatory = $false)]
    [Switch]
    $PassThru
  )
  
  $secure = Read-Host -AsSecureString 'Enter your Azure organization ID password.'
  $encrypted = ConvertFrom-SecureString -SecureString $secure
  $result = Set-Content -Path $FilePath -Value $encrypted -PassThru
  
  if (!$result)
  {
    throw 'Failed to store encrypted string at [$FilePath].'
  }
  if ($PassThru)
  {
    Get-ChildItem $FilePath
  }
}

#endregion Functions
#region connect to MSOnline
try {
  if (-not (Get-Module -Name MSOnline)) {
    $null = Import-Module -Name MSOnline
  }
} 
catch {
  Write-Error -Message {0} -f $PSItem;
}

$FilePath = Save-Password -FilePath 'C:\Users\David\OneDrive\Scripts\Azure\Password_MSOL.txt' -PassThru #Change the Filepath before use!
$securePassword = ConvertTo-SecureString (Get-Content -Path $FilePath)
$msolcred = New-Object System.Management.Automation.PSCredential($AzureUserName, $securePassword)

connect-msolservice -credential $msolcred -Verbose

#endregion connect to MSOnline

#region mass import of users

$userdata = Import-Csv -Delimiter ',' -Path $PathToCsv

foreach ($user in $userdata) {
  $MSOLUser = @{
    UserPrincipalName   = $user.Email;
    City                = $user.City;
    Country             = 'Australia';
    DisplayName         = '{0} {1}' -f $user.'First Name', $user.'Last Name';
    FirstName           = $user.'First Name';
    LastName            = $user.'Last Name';
    State               = $user.State;
    Password            = 'Starter123';
    ForceChangePassword = $true;
  } 
  New-MsolUser @MSOLUser
  if ($SendMail) 
  {
    $MailBody = @"
Your new Azure Active Directory user account has been created at $(Get-Date).

User Name = $($user.Email)
Password = Starter123

You need to change your Password upon first login.
"@
    $EmailPassword = ConvertTo-SecureString -AsPlainText -force $(Secure-Password -Decrypt -EncryptedPWD $EmailPasswordEncrypted)
    $EMailcred = New-Object System.Management.Automation.PSCredential $EmailUser,$EmailPassword
    Send-MailMessage -SmtpServer $SmtpServer -Body $MailBody -From 'obrien.david@outlook.com' -Subject 'Your new user Account' -To $user.Email -UseSsl -Credential $EMailcred
  }
}

#endregion mass import of users
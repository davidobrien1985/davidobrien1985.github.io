﻿Configuration GoogleChrome {

  Import-DSCResource -Modulename xPSDesiredStateConfiguration
  Import-DSCResource -Modulename xChrome
  
    MSFT_xChrome InstallChrome {
       LocalPath = 'C:\Windows\temp\Googlechrome.msi'
       Language = 'en'
    }
}
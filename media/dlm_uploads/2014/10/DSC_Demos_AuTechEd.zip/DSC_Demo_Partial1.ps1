﻿#region ConfigurationData
$ConfigurationData = @{

  AllNodes = @(
    @{
      NodeName = '*';
      PSDscAllowPlainTextPassword = $true
    }
    
    @{
        NodeName = '94b66042-16b8-4abe-9c33-0cd021050603';
        Roles = 'MySQL';
        ComputerName = 'DSCServer03'
        PSDscAllowPlainTextPassword = $true
    }
  )
}

#endregion ConfigurationData

Configuration OSConfig {
  
  Import-DscResource -Modulename xComputerManagement
  $pwd = ConvertTo-SecureString '' -AsPlainText -Force
  $Credential = New-Object System.Management.Automation.PSCredential ('', $pwd)
  
  Node $AllNodes.Where{$PSItem.Roles -eq 'MySQL'}.NodeName {
    
    xComputer JoinDomain {
      Credential = $Credential
      DomainName = 'do.local'
      Name = $Node.ComputerName
    }
    
    Group LocalGroups {
      GroupName = 'LocalAdmins'
      Members = 'DO\SC_Admins'
      Ensure = 'Present'  
    }
  }
}

OSConfig -ConfigurationData $ConfigurationData -OutputPath '\\dscserver01\C$\Program Files\WindowsPowerShell\DscService\Configuration'

New-DSCCheckSum -ConfigurationPath '\\dscserver01\C$\Program Files\WindowsPowerShell\DscService\Configuration' `
-OutPath '\\dscserver01\C$\Program Files\WindowsPowerShell\DscService\Configuration' -Force
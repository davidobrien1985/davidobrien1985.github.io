﻿#region prep
$Computers = @('DSCServer03.do.local')

Write-Output 'Generating GUIDs and creating MOF files...'
foreach ($Node in $Computers)
{
  $NewGUID = [guid]::NewGuid()
  $NewLine = '{0},{1}' -f $Node,$NewGUID
  $NewLine | add-content -path `
  "\\dscserver01\C$\Program Files\WindowsPowerShell\DscService\Configuration\dscnodes.csv"
}

#endregion prep

#region ConfigurationData
$ConfigurationData = @{

  AllNodes = @(
    @{
      NodeName = '*';
      PSDscAllowPlainTextPassword = $true
      DomainName = 'do.local';
    };
    
    @{
        NodeName = '94b66042-16b8-4abe-9c33-0cd021050603';
        Roles = 'NLB';
        ComputerName = 'DSCServer03';
        PSDscAllowPlainTextPassword = $true
    };

    @{
        NodeName = 'ea9f4db4-7874-466b-ba00-462db2c71532';
        Roles = 'Web';
        ComputerName = 'WebServer001';
        PSDscAllowPlainTextPassword = $true
    }
  )
}

#endregion ConfigurationData

#region Configuration
Configuration ConfigData {
  
  Import-DscResource -Modulename xComputerManagement
  $pwd = ConvertTo-SecureString '' -AsPlainText -Force
  $Credential = New-Object System.Management.Automation.PSCredential ('', $pwd)
  
  Node $AllNodes.Where{$PSItem.Roles -eq 'NLB'}.NodeName {
    
    xComputer JoinDomain {
      Credential = $Credential
      DomainName = $Node.DomainName
      Name = $Node.ComputerName
    }
    
    WindowsFeature NLB {
      Name = $Node.Roles
      Ensure = 'Present'
    }
  }
  
  Node $AllNodes.Where{$PSItem.Roles -eq 'Web'}.NodeName {
    
    xComputer JoinDomain {
      Credential = $Credential
      DomainName = $Node.DomainName
      Name = $Node.ComputerName
    }
    
    WindowsFeature Web {
      Name = $Node.Roles
      Ensure = 'Present'
    }
  }
  
  Node $AllNodes.NodeName {
    Group LocalGroup {
      GroupName = 'ManagedGroup'
      Ensure = 'Present'
    }
  }
}

#endregion Configuration

#region Execution

ConfigData -ConfigurationData $ConfigurationData `
-OutputPath '\\dscserver01\C$\Program Files\WindowsPowerShell\DscService\Configuration'

New-DSCCheckSum -ConfigurationPath `
'\\dscserver01\C$\Program Files\WindowsPowerShell\DscService\Configuration' `
-OutPath '\\dscserver01\C$\Program Files\WindowsPowerShell\DscService\Configuration' -Force

#endregion Execution
﻿$ConfigurationData = @{
    AllNodes = @(
        @{ 
          NodeName = 'DSCServer03'; 
          PsDscAllowPlainTextPassword = $true 
        }
    )
}


configuration WaitForMe {

  $pwd = ConvertTo-SecureString '' -AsPlainText -Force
  $Credential = New-Object System.Management.Automation.PSCredential ('', $pwd)

  Node DSCServer03 {
    
    WindowsFeature NLB {
      Name = 'NLB'
      Ensure = 'Present'
    }

    WaitForAll Config {
      NodeName = 'DSCServer02'
      ResourceName = '[WindowsFeature]NLB'
      RetryIntervalSec = 10
      RetryCount = 10
      Credential = $Credential
    }

    Group Admin {
      GroupName = 'NLBAdmins'
    }
  }

  Node DSCServer02 {
    WindowsFeature NLB {
      Name = 'NLB'
      Ensure = 'Present'
    }
  }

}

WaitForMe -ConfigurationData $ConfigurationData
﻿Configuration AUTechEdSydney
{
  
  Group LocalGroup 
  {
    Ensure = 'Present'
    GroupName = 'AUTechEd'
  }
}

#region exec
Set-Location C:\users\$env:USERNAME\DSCDemo
AUTechEdSydney 

Start-DscConfiguration -Path $path -Wait -Verbose -ComputerName localhost
#endregion
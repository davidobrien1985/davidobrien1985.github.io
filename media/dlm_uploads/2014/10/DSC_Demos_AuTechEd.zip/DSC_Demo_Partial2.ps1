﻿#region ConfigurationData
$ConfigurationData = @{

  AllNodes = @(
    @{
      NodeName = '*';
      PSDscAllowPlainTextPassword = $true
    }
    
    @{
        NodeName = '94b66042-16b8-4abe-9c33-0cd021050603';
        Roles = 'MySQL';
        ComputerName = 'DSCServer03';
        PSDscAllowPlainTextPassword = $true;
        PackageProductID = '{437AC169-780B-47A9-86F6-14D43C8F596B}'
    }
  )
}

#endregion ConfigurationData

Configuration ApplicationConfig {
  
  param
  (
    [parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $MySQLInstancePackagePath,
    
    [parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String] $MySQLInstancePackageName
  )
  
  
  $pwd = ConvertTo-SecureString '' -AsPlainText -Force
  $Credential = New-Object System.Management.Automation.PSCredential ('', $pwd)
  
  Import-DscResource -Module xMySql,xPSDesiredStateConfiguration
  
  node $AllNodes.Where{$PSItem.Roles -eq 'MySQL'}.NodeName {
    
    xPackage mySqlInstaller
    {
      
      Path = $MySQLInstancePackagePath
      ProductId = $Node.PackageProductID 
      Name = $MySQLInstancePackageName
    }
    
    xMySqlServer MySQLInstance
    {
      Ensure = 'Present'
      RootPassword = $Credential
      ServiceName = 'MySQLServerInstanceName'
      DependsOn = '[xPackage]mySqlInstaller'
    }
  }
}

ApplicationConfig `
-MySQLInstancePackagePath 'http://dev.mysql.com/get/Downloads/MySQLInstaller/mysql-installer-community-5.6.17.0.msi' `
-MySQLInstancePackageName 'MySQL Installer' -ConfigurationData $ConfigurationData `
-OutputPath '\\dscserver01\C$\Program Files\WindowsPowerShell\DscService\Configuration'

New-DSCCheckSum -ConfigurationPath '\\dscserver01\C$\Program Files\WindowsPowerShell\DscService\Configuration' `
-OutPath '\\dscserver01\C$\Program Files\WindowsPowerShell\DscService\Configuration' -Force
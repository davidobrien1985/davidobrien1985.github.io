﻿#region PushOld
configuration LCMConfigOld {
  
  Node localhost
  {
    
    LocalConfigurationManager
    {
      ConfigurationMode = 'ApplyAndMonitor'
      RefreshFrequencyMins = 15
      ConfigurationModeFrequencyMins = 20
      RefreshMode = 'PUSH'
      RebootNodeIfNeeded = $true      
    }
  }
}

Set-Location ~\DSCDemo

LCMConfigOld

#Set-DscLocalConfigurationManager -Path .\LCMConfigOld -ComputerName DSCServer02.do.local 

#endregion

#region PushNew
[DSCLocalConfigurationManager()]
Configuration LCMConfigNew
{
  Node localhost
  {
    Settings
    {
      ConfigurationMode = 'ApplyAndMonitor'
      RefreshFrequencyMins = 15
      ConfigurationModeFrequencyMins = 20
      RefreshMode = 'Push'
      DebugMode = $true
      RebootNodeIfNeeded = $true  
    }
  }
}

Set-Location ~\DSCDemo
LCMConfigNew 
Set-DscLocalConfigurationManager -Path .\LCMConfigNew -ComputerName DSCServer03.do.local 

#endregion

#region Pull for WMF5 on DSCServer03
[DSCLocalConfigurationManager()]
Configuration LCMConfigNew
{
  param (
    $NodeName
  )
  
  Node $NodeName
  {
    Settings
    {
      ConfigurationID = '94b66042-16b8-4abe-9c33-0cd021050603';
      RefreshMode = 'PULL';
      RebootNodeIfNeeded = $true;
      RefreshFrequencyMins = 15;
      ConfigurationModeFrequencyMins = 30; 
      ConfigurationMode = 'ApplyAndMonitor';
      DebugMode = $true;
      AllowModuleOverwrite = $true;
    }
    ConfigurationRepositoryWeb PullServer {
      ServerURL = 'http://DSCSERVER01.do.local:8080/PullSvc/PSDSCPullServer.svc'
      AllowUnsecureConnection = $true
    }
  }
}

Set-Location C:\Users\David\DSCDemo
LCMConfigNew -NodeName localhost
#Set-DscLocalConfigurationManager -Path '\\nb-dobrien\c$\Users\David\DSCDemo\LCMConfigNew' -Verbose -ComputerName localhost

#endregion Push
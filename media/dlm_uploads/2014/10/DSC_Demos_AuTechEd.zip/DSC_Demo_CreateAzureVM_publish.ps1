﻿
Publish-AzureVMDscConfiguration -ConfigurationPath `
 'C:\Users\David\OneDrive\Events\TechEd AU\Sydney_DSC\DSC_Demo_ChromeConfig.ps1' `
  -ConfigurationArchivePath 'C:\Users\David\OneDrive\Events\TechEd AU\Sydney_DSC\DSC_Demo_ChromeConfig.ps1.zip' -Force

Publish-AzureVMDscConfiguration -ConfigurationPath `
 'C:\Users\David\OneDrive\Events\TechEd AU\Sydney_DSC\DSC_Demo_ChromeConfig.ps1' -Verbose -Force

$vm = New-AzureVMConfig -Name 'DOPSDSCAUTechEd' -InstanceSize Small -ImageName `
 'a699494373c04fc0bc8f2bb1389d6106__Windows-Server-2012-R2-201409.01-en.us-127GB.vhd' -Verbose

$vm = Add-AzureProvisioningConfig -VM $vm -Windows -AdminUsername 'adobrien' -Password 'P@ssw0rd' -Verbose

$vm = Add-AzureEndpoint -VM $vm -Name 'HTTP' -Protocol 'tcp' -PublicPort 80 -LocalPort 8080

$vm = Set-AzureVMDSCExtension -VM $vm -ConfigurationArchive 'DSC_Demo_ChromeConfig.ps1.zip' `
 -ConfigurationName 'GoogleChrome' -Verbose -Force

New-AzureVM -VM $vm -Location 'West US' -ServiceName 'DOPSDSCAUTechEd-svc' -WaitForBoot -Verbose




$vm = Get-AzureVM –ServiceName 'DOPSDSCAUTechEd-svc' –Name 'DOPSDSCAUTechEd'
$rdp = Get-AzureEndpoint -Name 'RemoteDesktop' -VM $vm 
$hostdns = (New-Object 'System.Uri' $vm.DNSName).Authority 
$port = $rdp.Port 
Start-Process 'mstsc' -ArgumentList "/V:$hostdns`:$port /w:1024 /h:768"  
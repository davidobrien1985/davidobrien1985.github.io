﻿Configuration SMAWorker
    {
        param ( $NodeName )
        Node $NodeName
        {
            LocalConfigurationManager
                {
                    ConfigurationMode = "ApplyAndAutocorrect"
                    RefreshMode = "Push"
                    RefreshFrequencyMins = 15
                    RebootNodeIfNeeded = $true
                    ConfigurationModeFrequencyMins = 30
                }
            
            WindowsFeature WebServer
                {
                    Ensure = "Present" # To uninstall the role, set Ensure to "Absent"
                    Name = "Web-Server"
                }
            WindowsFeature IISConsole
                {
                    Ensure = "Present" # To uninstall the role, set Ensure to "Absent"
                    Name = "Web-Mgmt-Console"
                    DependsOn = "[WindowsFeature]WebServer"  
                }
            WindowsFeature IISBasicAuth
                {
                    Ensure = "Present" # To uninstall the role, set Ensure to "Absent"
                    Name = "Web-Basic-Auth"
                    DependsOn = "[WindowsFeature]WebServer"
                }
            WindowsFeature IISWindowsAuth
                {
                    Ensure = "Present" # To uninstall the role, set Ensure to "Absent"
                    Name = "Web-Windows-Auth"
                    DependsOn = "[WindowsFeature]WebServer"
                }
            WindowsFeature IISURLAuth
                {
                    Ensure = "Present" # To uninstall the role, set Ensure to "Absent"
                    Name = "Web-Url-Auth"
                    DependsOn = "[WindowsFeature]WebServer"
                }
            WindowsFeature ASPNet45
                {
                    Ensure = "Present" # To uninstall the role, set Ensure to "Absent"
                    Name = "Web-Asp-Net45"
                    DependsOn = "[WindowsFeature]WebServer"
                }
            WindowsFeature DotNet35
                {
                    Ensure = "Present" # To uninstall the role, set Ensure to "Absent"
                    Name = "NET-Framework-Features"
                    Source = "\\dc01\sources\OSD\OSSources\W12R2\sources\sxs"
                }
            WindowsFeature DotNet35Core
                {
                    Ensure = "Present" # To uninstall the role, set Ensure to "Absent"
                    Name = "NET-Framework-Core"
                    DependsOn = "[WindowsFeature]DotNet35"
                    Source = "\\dc01\sources\OSD\OSSources\W12R2\sources\sxs"
                }
            WindowsFeature DotNet45Features
                {
                    Ensure = "Present" # To uninstall the role, set Ensure to "Absent"
                    Name = "NET-Framework-45-Features"
                }
            WindowsFeature DotNet45Core
                {
                    Ensure = "Present" # To uninstall the role, set Ensure to "Absent"
                    Name = "NET-Framework-45-Core"
                    DependsOn = "[WindowsFeature]DotNet45Features"
                }
            WindowsFeature NetWCFHTTPActivation
                {
                    Ensure = "Present" # To uninstall the role, set Ensure to "Absent"
                    Name = "NET-WCF-HTTP-Activation45"
                    DependsOn = "[WindowsFeature]DotNet45Features"
                }
            #SMA PowershellModule
            Package SMAPowershellModule
            {
                Name = "System Center 2012 R2 Service Management Automation Powershell"
                Path = "\\dc01\sources\Software\Microsoft\Orchestrator\SMA\PowershellModuleInstaller.msi"
                ProductId = "EF2760C1-FED5-45FD-B067-D9419F7DEBEF"
                Ensure = "Present"
                ReturnCode = 0
                DependsOn = "[WindowsFeature]DotNet35"
            }
            #SMA Webservice
            Package SMAWebService
            {
                Name = "System Center 2012 R2 Service Management Automation Web Service"
                Path = "\\dc01\sources\Software\Microsoft\Orchestrator\SMA\WebServiceInstaller.msi"
                ProductId = "4B76B636-AE9A-47D5-A246-E02909D97CF2"
                Arguments = "/L*v C:\Windows\System32\LogFiles\SMAWebServiceInstaller.log SQLSERVER=`"CM01.DO.LOCAL,1433`" DATABASEAUTHENTICATION=`"SQL`" SQLDATABASE=`"SMA`" SQLUSER=`"sa`" SQLPASSWORD=`P@ssw0rd`" APPOOLACCOUNT=`"DO\SMA_AppPool`" APPOOLPASSWORD=`"P@ssw0rd`""
                Ensure = "Present"
                DependsOn = "[Package]SMAPowershellModule"
                ReturnCode = 0
            }
            #SMA RunbookWorker
            Package SMARunbookWorker
            {
                Name = "System Center 2012 R2 Service Management Automation Runbook Worker"
                Path = "\\dc01\sources\Software\Microsoft\Orchestrator\SMA\WorkerInstaller.msi"
                ProductId = "B2FA6B22-1DDF-4BD4-8B92-ADF17D48262F"
                Arguments = "/L*v C:\Windows\System32\LogFiles\SMAWorkerInstaller.log MSUPDATE=`"No`" SQLSERVER=`"CM01.DO.LOCAL,1433`" DATABASEAUTHENTICATION=`"SQL`" SQLDATABASE=`"SMA`" SQLUSER=`"sa`" SQLPASSWORD=`"P@ssw0rd`" SERVICEACCOUNT=`"DO\SMA_Runbook`" SERVICEPASSWORD=`"P@ssw0rd`" SENDCEIPREPORTS=`"no`""
                Ensure = "Present"
                DependsOn = "[Package]SMAPowershellModule"
                ReturnCode = 0
            }
        }
    }
SMAWorker -NodeName $env:COMPUTERNAME
﻿$ConfigData= 
@{ 
    AllNodes =
        @(
            @{ 
                NodeName= '*'
                PSDscAllowPlainTextPassword = $true
            },
            @{
                NodeName = 'DSCServer02.do.local'
            }
        );
}

configuration CM12 {
    param(
        [Parameter(Mandatory=$false)]
        [ValidateNotNullorEmpty()]
        [PsCredential] $credential
        )

    #Import-DscResource -Module xSqlPs
    Import-DscResource -Module cConfigMgr2012
    Node $AllNodes.NodeName {
            <#
            Log startconfig 
                { 
                    # The message below gets written to the Microsoft-Windows-Desired State Configuration/Analytic log 
                    Message = "starting the file resource with ID MyProfile with $($myinvocation.mycommand) user : $env:username" 
                }
            #>
            WindowsFeature WebServer
                {
                    Ensure = 'Present' # To uninstall the role, set Ensure to "Absent"
                    Name = 'Web-Server'
                    #IncludeAllSubFeature = "true"  
                }
            WindowsFeature IISConsole
                {
                    Ensure = 'Present' # To uninstall the role, set Ensure to "Absent"
                    Name = 'Web-Mgmt-Console'
                    DependsOn = '[WindowsFeature]WebServer'  
                }
            WindowsFeature IISBasicAuth
                {
                    Ensure = 'Present' # To uninstall the role, set Ensure to "Absent"
                    Name = 'Web-Basic-Auth'
                    DependsOn = '[WindowsFeature]WebServer'
                }
            WindowsFeature IISWindowsAuth
                {
                    Ensure = 'Present' # To uninstall the role, set Ensure to "Absent"
                    Name = 'Web-Windows-Auth'
                    DependsOn = '[WindowsFeature]WebServer'
                }
            WindowsFeature IISURLAuth
                {
                    Ensure = 'Present' # To uninstall the role, set Ensure to "Absent"
                    Name = 'Web-Url-Auth'
                    DependsOn = '[WindowsFeature]WebServer'
                }
            WindowsFeature ASPNet45
                {
                    Ensure = 'Present' # To uninstall the role, set Ensure to "Absent"
                    Name = 'Web-Asp-Net45'
                    DependsOn = '[WindowsFeature]WebServer'
                }
            WindowsFeature RDC
                {
                    Ensure = 'Present' # To uninstall the role, set Ensure to "Absent"
                    Name = 'RDC'
                }
            WindowsFeature BITS
                {
                    Ensure = 'Present' # To uninstall the role, set Ensure to "Absent"
                    Name = 'BITS'
                }
            WindowsFeature DotNet35
                {
                    Ensure = 'Present' # To uninstall the role, set Ensure to "Absent"
                    Name = 'NET-Framework-Features'
                    Source = '\\dc01\sources\OSD\OSSources\W12R2\sources\sxs'
                }
            WindowsFeature DotNet35Core
                {
                    Ensure = 'Present' # To uninstall the role, set Ensure to "Absent"
                    Name = 'NET-Framework-Core'
                    DependsOn = '[WindowsFeature]DotNet35'
                    Source = '\\dc01\sources\OSD\OSSources\W12R2\sources\sxs'
                }
            WindowsFeature DotNet45Features
                {
                    Ensure = 'Present' # To uninstall the role, set Ensure to "Absent"
                    Name = 'NET-Framework-45-Features'
                }
            WindowsFeature DotNet45Core
                {
                    Ensure = 'Present' # To uninstall the role, set Ensure to "Absent"
                    Name = 'NET-Framework-45-Core'
                    DependsOn = '[WindowsFeature]DotNet45Features'
                }
            WindowsFeature NetWCFHTTPActivation
                {
                    Ensure = 'Present' # To uninstall the role, set Ensure to "Absent"
                    Name = 'NET-WCF-HTTP-Activation45'
                    DependsOn = '[WindowsFeature]DotNet45Features'
                }
            Package DeploymentTools #From http://powershell.org/wp/forums/topic/installing-adk-8-1-with-dsc/
                {
                  Name = "ADK Deployment Tools"
                  Path = "\\dc01\deployment\Source\Prerequisites\ADK81\adksetup.exe"
                  ProductId = "FEA31583-30A7-0951-718C-AF75DCB003B1"
                  Arguments = "/quiet /features OptionId.DeploymentTools /norestart "
                  Ensure = "Present"
                  ReturnCode = 0
                }
            Package PreinstallationEnvironmentTools
                {
                  Name = "ADK Preinstallation Environment"
                  Path = "\\dc01\deployment\Source\Prerequisites\ADK81\adksetup.exe"
                  ProductId = "6FDE09DB-D711-593B-0823-D99D2A757227"
                  Arguments = "/quiet /features OptionId.WindowsPreinstallationEnvironment /norestart "
                  Ensure = "Present"
                  ReturnCode = 0
                }
            Package UserStateMigrationTools
                {
                  Name = "ADK Deployment Tools"
                  Path = "\\dc01\deployment\Source\Prerequisites\ADK81\adksetup.exe"
                  ProductId = "0C4384AC-02DB-B4E5-E537-EE6CF22392CF"
                  Arguments = "/quiet /features OptionId.UserStateMigrationTool /norestart "
                  Ensure = "Present"
                  ReturnCode = 0
                }
            cConfigMgr2012 PrimarySite
                {
                    SiteCode = 'DSC'
                    SiteName = 'DSC Test Site'
                    SQLServer = "$($Node.NodeName)"
                    PrereqPath = 'C:\Windows\temp'
                    SourcePath = '\\dc01\Deployment\Source\SystemCenter2012R2\ConfigurationManager'
                    #SQLServerInstance = 'CM12'
                    DPServer = "$($Node.NodeName)"
                    MPServer = "$($Node.NodeName)"
                    SMSProviderServer = "$($Node.NodeName)"
                    InstallationDirectory = 'C:\CM12'
                    DependsOn =  '[Package]DeploymentTools'                
                }
            <#
            xSqlServerInstall installSqlServer
                {
                    InstanceName = "CM12"
                    SourcePath = '\\dc01\Deployment\Source\SQLServer2012.en'
                    Features= "SQLEngine,SSMS"
                    SqlAdministratorCredential = $credential
                    SvcAccount = 'do\adobrien'
                    DependsOn = "[WindowsFeature]dotNet35"
                }
                # Disabled, because too many things missing, Collation, Static Port for Named Instance...
            #>
        }
    }


CM12 -ConfigurationData $ConfigData -OutputPath C:\temp\CM12 # -credential (Get-Credential -UserName "sa" -Message "Enter password for SqlAdministrator sa")

#Start-DscConfiguration -Wait -Path C:\temp\CM12 -Verbose
function Get-TargetResource {
}

function Set-TargetResource {
}

function Test-TargetResource {
}

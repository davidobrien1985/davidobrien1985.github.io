﻿param
(
$SMSProvider
)


Function Get-SiteCode
{
    $wqlQuery = “SELECT * FROM SMS_ProviderLocation”
    $a = Get-WmiObject -Query $wqlQuery -Namespace “root\sms” -ComputerName $SMSProvider
    $a | ForEach-Object {
        if($_.ProviderForLocalSite)
            {
                $script:SiteCode = $_.SiteCode
            }
    }
return $SiteCode
}

Get-SiteCode

<# 
ObjectType can be the following
2       = A Folder under the Packages Node
9       = A Folder under the Software Metering Node
14      = A Folder under the OS Installers Node
16      = A Folder under the Virtual Hard Disks Node
17      = A Folder under the User Collections Node
18      = A Folder under the OS Images Node
19      = A Folder under the Boot Images Node
20      = A Folder under the Task Sequences Node
23      = A Folder under the Driver Packages Node
25      = A Folder under the Drivers Node
1011    = A Folder under the Software Updates Node
2011    = A Folder under the Configuration Baselines Node
5000    = A Folder under the Device Collections Node
6000    = A Folder under the Applications Node
6001    = A Folder under the Configuration Items Node

#>

$Folders = Get-WmiObject -Class SMS_ObjectContainerNode -Namespace root\SMS\site_$($SiteCode) -ComputerName $($SMSProvider) -Filter "ObjectType = '2'"


foreach ($Folder in $Folders)
    {
        Write-Output "Editing Folder $($Folder.Name)"
        
        $Folder.Name = $Folder.Name.ToString() + "_DEV"
        $Folder.Put() | Out-Null
    }
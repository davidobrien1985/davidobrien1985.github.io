﻿<#
.Synopsis
   Backup and removal of Sample SMA runbooks
.DESCRIPTION
   This function will get all runbook definitions where the SMA Runbook name begins with 'Sample', will create a PS1 file for each runbook and then remove the 
   runbook
.EXAMPLE
   Backup-SMASampleRunbooks -SMAEndpoint https://smaserver -OutputPath C:\temp
#>
function Backup-SMASampleRunbooks
{
  [CmdletBinding()]
  Param
  (
    [Parameter(Mandatory=$true,
        ValueFromPipelineByPropertyName=$true,
    Position=0)]
    $SMAEndPoint,
    
    [Parameter(Mandatory=$true,
        ValueFromPipelineByPropertyName=$true,
    Position=1)]
    $OutputPath
  )
  

    $Runbooks = Get-SmaRunbook -WebServiceEndpoint $SMAEndPoint | Where-Object {$PSItem.RunbookName -like 'Sample*'} 
    foreach ($Runbook in $Runbooks) {
      $Definition = Get-SmaRunbookDefinition -Name $Runbook.RunbookName -Type Published -WebServiceEndpoint $SMAEndPoint 
      $Definition.Content | Out-File (Join-Path $OutputPath "$($Runbook.RunbookName).ps1")
      Remove-SmaRunbook -Name $Runbook.RunbookName -WebServiceEndpoint $SMAEndPoint -Verbose #-WhatIf
    }

}

﻿<#
 Demo Script for Azure Active Directory Automation

 http://msdn.microsoft.com/en-us/library/azure/jj151815.aspx#bkmk_installmodule
#>

#region Functions
Function Save-Password
{
  Param
  (
    [parameter(Mandatory = $true)]
    [String]
    $FilePath,
    
    [parameter(Mandatory = $false)]
    [Switch]
    $PassThru
  )
  
  $secure = Read-Host -AsSecureString 'Enter your Azure organization ID password.'
  $encrypted = ConvertFrom-SecureString -SecureString $secure
  $result = Set-Content -Path $FilePath -Value $encrypted -PassThru
  
  if (!$result)
  {
    throw "Failed to store encrypted string at $FilePath."
  }
  if ($PassThru)
  {
    Get-ChildItem $FilePath
  }
}

#endregion Functions
#region connect to MSOnline
try {
  if (-not (Get-Module -Name MSOnline)) {
    $null = Import-Module -Name MSOnline
  }
} 
catch {
  Write-Error -Message {0} -f $PSItem;
}

$FilePath = Save-Password -FilePath 'C:\Users\David\OneDrive\Scripts\Azure\Password_MSOL.txt' -PassThru #Change the Filepath before use!
$userName = 'PS@doautomation.onmicrosoft.com' #Change the username before use!
$securePassword = ConvertTo-SecureString (Get-Content -Path $FilePath)
$msolcred = New-Object System.Management.Automation.PSCredential($userName, $securePassword)

connect-msolservice -credential $msolcred -Verbose

#endregion connect to MSOnline

#region New Domain

New-MsolDomain -Name ps.ftw -Authentication Managed -VerificationMethod None -Verbose
Remove-MsolDomain -DomainName ps.ftw
#endregion new Domain


#region New User
$MSOLUser = @{
  UserPrincipalName   = 'BrisbaneInfra@doautomation.onmicrosoft.com';
  City                = 'Brisbane';
  Country             = 'Australia';
  DisplayName         = 'Brisbane Infrastructure Saturday 2014';
  FirstName           = 'Brisbane Infrastructure';
  LastName            = 'Saturday 2014';
  State               = 'QLD';
  Password            = 'Starter123';
  ForceChangePassword = $true;

} 

New-MsolUser @MSOLUser -Verbose

#region mass import of users

$userdata = Import-Csv -Delimiter ',' -Path C:\Users\David\OneDrive\Events\InfraSat2014\userdata.csv 

foreach ($user in $userdata) {
  $MSOLUser = @{
  UserPrincipalName   = $user.Email;
  City                = $user.City;
  Country             = 'Australia';
  DisplayName         = '{0} {1}' -f $user.'First Name', $user.'Last Name';
  FirstName           = $user.'First Name';
  LastName            = $user.'Last Name';
  State               = $user.State;
  Password            = 'Starter123';
  ForceChangePassword = $true;
  } 
New-MsolUser @MSOLUser
}

#endregion mass import of users



$User = Get-MsolUser -UserPrincipalName 'BrisbaneInfra@doautomation.onmicrosoft.com'

Set-MsolUser -UsageLocation 'AU' -ObjectId $User.ObjectId -AlternateEmailAddresses 'alt@email.com' 

Set-MsolUserPassword -UserPrincipalName 'BrisbaneInfra@doautomation.onmicrosoft.com' -NewPassword 'Starter123' -ForceChangePassword

Remove-MsolUser -ObjectId $User.ObjectId # -RemoveFromRecycleBin

Restore-MsolUser -UserPrincipalName 'BrisbaneInfra@doautomation.onmicrosoft.com'

#Mass removal of user accounts
Get-MsolUser | foreach {
  if (-not (($PSItem.DisplayName -ilike ("David O'Brien")) -or ($PSItem.UserPrincipalName -ilike 'BrisbaneInfra@doautomation.onmicrosoft.com') -or ($PSItem.UserPrincipalName -ilike 'PS@doautomation.onmicrosoft.com'))) {
    $PSItem | Remove-MsolUser -Force
  }
}

$MSOlGroup = @{
  DisplayName = 'BIG2014';
  Description = 'Group of users for Brisbane Infrastructure Saturday 2014';
}

New-MsolGroup @MSOlGroup -Verbose

$Group = (Get-MsolGroup).Where({$PSItem.DisplayName -eq 'BIG2014'})

$GroupMember = @{
  GroupObjectId        = $Group.ObjectId;
  GroupMemberObjectId  = $User.ObjectId;
}

Add-MsolGroupMember @GroupMember -Verbose

#region Multi-Factor Auth

#Create the StrongAuthenticationRequirement object
$MultiFactor = New-Object -TypeName Microsoft.Online.Administration.StrongAuthenticationRequirement
$MultiFactor.RelyingParty = '*'
$MultiFactorAuth = @($MultiFactor)

#region Enable MFA for a user

Set-MsolUser -UserPrincipalName $User.UserPrincipalName -StrongAuthenticationRequirements $MultiFactorAuth

$FilePath = Save-Password -FilePath 'C:\Users\David\OneDrive\Scripts\Azure\Password_Mail.txt' -PassThru
$FilePath = 'C:\Users\David\OneDrive\Scripts\Azure\Password_Mail.txt'
$userName = 'obrien.david@outlook.com'
$securePassword = ConvertTo-SecureString (Get-Content -Path $FilePath)
$mailcred = New-Object System.Management.Automation.PSCredential($userName, $securePassword)
$Subject = 'ACTION REQUIRED: Your password for Outlook and other apps needs updated'
$Body = 
@'
For added security, we have enabled multi-factor authentication for your account. 

Action Required: You will need to complete the enrollment steps below to make your account secure with multi-factor authentication.  

What to expect once MFA is enabled:

Multi-factor authentication requires a password that you know and a phone that you have in order to sign into browser applications and to access Office 365, Azure portals.

For Office 365 non-browser applications such as outlook, lync, a mail client on your mobile device etc, a special password called an app password is required instead of your account password to sign in. App passwords are different than your account password, and are generated during the multi-factor authentication set up process. 

Please follow these enrollment steps to avoid interruption of your Office 365 service:

1.  Sign in to the Office 365 Portal at http://portal.microsoftonline.com.
2.  Follow the instructions to set up your preferred multi-factor authentication method when signing into Office 365 using a web browser. 
3.  Create one app password for each device.
4.  Enter the same app password in all applicable apps on that device e.g. Outlook, Mail client, Lync, Word, Powerpoint, Excel, CRM etc. 
5.  Update your Office client applications or other mobile applications to use an app password.

You can visit http://aka.ms/mfasetup to create app passwords or change your MFA Setting.  Please bookmark this.

NOTE: Before entering an app password, you will need to clear the sign-in information (delete sign-in info), restart the application,   and sign-in with the username and app password. Follow the steps documented : http://technet.microsoft.com/en-us/library/dn270518.aspx#apppassword.


Watch a video showing these steps at http://g.microsoftonline.com/1AX00en/175.

Best Regards,
Your Administrator
'@

Send-MailMessage -Body $Body -Subject $Subject -From 'obrien.david@outlook.com' -To 'obrien.david@outlook.com' -SmtpServer smtp.live.com -UseSsl -Credential $mailcred
#endregion Enable MFA for a user
 
#Enable MFA for all users
Get-MsolUser -All | Set-MsolUser -StrongAuthenticationRequirements $MultiFactorAuth

#Disable MFA for a user
$MultiFactorAuth = @()
Set-MsolUser -UserPrincipalName $User.UserPrincipalName -StrongAuthenticationRequirements $MultiFactorAuth

#Find all MFA enabled users
Get-MsolUser | Where-Object {$_.StrongAuthenticationRequirements -like '*'}  | Select-Object UserPrincipalName,StrongAuthenticationMethods,StrongAuthenticationRequirements | Format-List * -Force
 
#Find all MFA enabled users that have enrolled their MFA methods
Get-MsolUser | Where-Object {$_.StrongAuthenticationMethods -like '*'}  | Select-Object UserPrincipalName,StrongAuthenticationMethods,StrongAuthenticationRequirements | Format-List * -Force

#region Notes on MFA
http://msdn.microsoft.com/en-us/library/azure/dn394289.aspx
#endregion Notes on MFA
#endregion MFA

Reset-MsolStrongAuthenticationMethodByUpn -UserPrincipalName BrisbaneInfra@doautomation.onmicrosoft.com
﻿$SMA = 'https://dosma01.ps.ftw'

If (Get-SmaRunbook -Name 'GetUpdates' -WebServiceEndpoint $SMA -Verbose) {
  Remove-SmaRunbook -Name 'GetUpdates' -WebServiceEndpoint $SMA -Verbose
}

$Runbook = Import-SmaRunbook -Path 'Z:\testdir\GetUpdates.ps1' -WebServiceEndpoint $SMA -Tags 'BIG2014' -Verbose
Get-SmaRunbook -Name 'GetUpdates' -WebServiceEndpoint $SMA -Verbose

Publish-SmaRunbook -Id $Runbook.RunbookID -WebServiceEndpoint $SMA -Verbose

Set-SmaRunbookConfiguration -Id $Runbook.RunbookID -LogDebug $true -WebServiceEndpoint $SMA -Verbose


$Job = Start-SmaRunbook -Id $Runbook.RunbookID -Parameters @{Computer='DOSQL01.ps.ftw'} -WebServiceEndpoint $SMA -Verbose

do {(Get-SmaJob -Id $Job -WebServiceEndpoint $SMA).JobStatus; Start-Sleep -Seconds 2}
while ((Get-SmaJob -Id $Job -WebServiceEndpoint $SMA).JobStatus -ne 'Completed')

(Get-SmaJobOutput -Id $Job -WebServiceEndpoint $SMA -Stream Output).StreamText
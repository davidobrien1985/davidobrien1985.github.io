﻿workflow GetUpdates {
  [CmdletBinding()]
  param (
    [parameter(Mandatory=$true)] 
    [string]$Computer
  )
  
  Get-HotFix -PSComputerName $Computer -Verbose
  
}
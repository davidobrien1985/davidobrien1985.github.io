﻿do {(Get-SmaJob -Id $Job -WebServiceEndpoint https://or01.do.local).JobStatus}
while ((Get-SmaJob -Id $Job -WebServiceEndpoint https://or01.do.local).JobStatus -ne 'Completed')
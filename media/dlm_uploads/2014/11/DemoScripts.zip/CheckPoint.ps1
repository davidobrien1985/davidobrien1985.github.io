﻿workflow CheckPoint {

$i = 0

do {
    $i
    $i++
    Checkpoint-Workflow
}
while ($i -lt 10000)

}

Checkpoint -AsJob
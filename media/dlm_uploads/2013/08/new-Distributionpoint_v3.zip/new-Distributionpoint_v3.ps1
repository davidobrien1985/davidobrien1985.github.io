﻿Function Set-WMIProperty
{
    PARAM(
        $sdkserver,
        $SiteCode,
        $PropertyName,
        $Value,
        $Value1,
        $Value2
    )

    $embeddedproperty_class = [wmiclass]""
    $embeddedproperty_class.psbase.Path = "\\" + $sdkserver + "\ROOT\SMS\site_" + $SiteCode + ":SMS_EmbeddedProperty"
    $embeddedproperty = $embeddedproperty_class.createInstance()
    
    $embeddedproperty.PropertyName = $PropertyName
    $embeddedproperty.Value = $Value
    $embeddedproperty.Value1 = $Value1
    $embeddedproperty.Value2 = $Value2
    
    return $embeddedproperty
}

Function global:Set-Property(
    $PropertyName,
    $Value,
    $Value1,
    $Value2,
    $roleproperties) 
{
            $embeddedproperty_class 			= [wmiclass]""
			$embeddedproperty_class.psbase.Path = "\\.\ROOT\SMS\Site_PR1:SMS_EmbeddedProperty"
			$embeddedproperty 					= $embeddedproperty_class.createInstance()
                        			
            $embeddedproperty.PropertyName  = $PropertyName
			$embeddedproperty.Value 		= $Value
			$embeddedproperty.Value1		= $Value1 
			$embeddedproperty.Value2		= $Value2
            $global:roleproperties += [System.Management.ManagementBaseObject]$embeddedproperty
	}


$sdkserver = "localhost"
$servername = "XA-DEPLOY.DO.LOCAL"
$sitecode = "PR1"

$scf = Invoke-WmiMethod -Namespace "root\SMS\site_$sitecode" -ComputerName $sdkserver -class "SMS_SiteControlFile" -name "GetSessionHandle"
$refresh = Invoke-WmiMethod -Namespace "root\SMS\site_$sitecode" -ComputerName $sdkserver -class "SMS_SiteControlFile" -name "RefreshSCF" -ArgumentList $sitecode

############### Create Site System ################################################
$global:roleproperties = @()
$global:properties =@()
# connect to SMS Provider for Site 
$role_class = [wmiclass]""
$role_class.psbase.Path ="\\.\ROOT\SMS\Site_PR1:SMS_SCI_SysResUse"
$script:role = $role_class.createInstance()

#create the SMS Site Server
$role.NALPath 	= "[`"Display=\\$servername\`"]MSWNET:[`"SMS_SITE=$sitecode`"]\\$servername\"
$role.NALType 	= "Windows NT Server"
$role.RoleName 	= "SMS SITE SYSTEM"
$role.SiteCode 	= "PR1"

#####
#filling in properties
$IsProtected					= @("IsProtected",1,"","")  # 0 to disable fallback to this site system, 1 to enable 
set-property $IsProtected[0] $IsProtected[1] $IsProtected[2] $IsProtected[3]
$role.Props = $roleproperties
$role.Put()
            
$role_class = [wmiclass]""  
$role_class.psbase.Path = "\\" + $sdkserver + "\ROOT\SMS\site_" + $SiteCode + ":SMS_SCI_SysResUse"

$siterole = $role_class.createInstance()
$siterole.NALPath = "[`"Display=\\$servername\`"]MSWNET:[`"SMS_SITE=$SiteCode`"]\\$servername\"
$siterole.NALType = "Windows NT Server"
$siterole.SiteCode = $SiteCode
$siterole.RoleName = "sms distribution point"

$pxeauth = new-object -comobject Microsoft.ConfigMgr.PXEAuth
$strSubject = [System.Guid]::NewGuid().toString()
$strSMSID = [System.Guid]::NewGuid().toString()
$StartTime = [DateTime]::Now.ToUniversalTime()
$EndTime = $StartTime.AddYears(25)
$ident = $pxeauth.CreateIdentity($strSubject, $strSubject, $strSMSID, $StartTime, $EndTime)

$smssite_class = [wmiclass]""
$smssite_class.psbase.Path = "\\" + $sdkserver + "\ROOT\SMS\site_" + $SiteCode + ":SMS_Site"

$inParams = $smssite_class.GetMethodParameters("SubmitRegistrationRecord")
$inParams["SMSID"] = $strSMSID
$inParams["Certificate"] = $ident[1]
$inParams["CertificatePFX"] = $ident[0]
$inParams["Type"] = 2
$inParams["ServerName"] = $servername
$inParams["UdaSetting"] = '2' 
$inParams["IssuedCert"] = '2' 
$outParams = $smssite_class.InvokeMethod("SubmitRegistrationRecord", $inParams, $null)

$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "IsPXE" -value 1 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "IsActive" -value 1 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "SupportUnknownMachines" -value 1 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "UDASetting" -value 2 -value1 '' -value2 '')

$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "BITS download" -value 0 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "Server Remote Name" -value 0 -value1 $servername -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "PreStagingAllowed" -value 0 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "SslState" -value 0 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "AllowInternetClients" -value 0 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "IsAnonymousEnabled" -value 0 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "DPDrive" -value 0 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "MinFreeSpace" -value 50 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "InstallInternetServer" -value 1 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "RemoveWDS" -value 0 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "BindPolicy" -value 0 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "ResponseDelay" -value 0 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "IdentityGUID" -value 0 -value1 $strSMSID -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "CertificatePFXData" -value 0 -value1 ($ident[0]) -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "CertificateContextData" -value 0 -value1 ($ident[1]) -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "PXEPassword" -value 0 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "CertificateType" -value 0 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "CertificateExpirationDate" -value 0 -value1 ([String]$EndTime.ToFileTime()) -value2 '')  
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "CertificateFile" -value 0 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "DPShareDrive" -value 0 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "IsMulticast" -value 0 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "DPMonEnabled" -value 1 -value1 '' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "DPMonSchedule" -value 0 -value1 '00011700001F2000' -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "DPMonPriority" -value 4 -value1 '' -value2 '')

$drive = Get-WmiObject Win32_LogicalDisk | where-object {($_.DriveType -eq 3) -and ($_.DeviceID -ne "c:")} | Sort-object $_.FreeSpace -descending
if ($drive -ne $null)
{
    foreach ($dr in $drive)
    { 
        $letterdrive = $dr.DeviceID
        break
    }
}
$letterdrive = $letterdrive -replace ':', ''

$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "AvailableContentLibDrivesList" -value 0 -value1 $letterdrive -value2 '')
$siterole.Props += [System.Management.ManagementBaseObject](Set-WMIProperty -sdkserver $sdkserver -sitecode $sitecode -PropertyName "AvailablePkgShareDrivesList" -value 0 -value1 $letterdrive -value2 '')


$siterole.Put() | Out-Null
$commit = Invoke-WmiMethod -Namespace "root\SMS\site_$sitecode" -ComputerName $sdkserver -class "SMS_SiteControlFile" -name "CommitSCF" $sitecode
$scf = Invoke-WmiMethod -Namespace "root\SMS\site_$sitecode" -ComputerName $sdkserver -class "SMS_SiteControlFile" -name "ReleaseSessionHandle" -ArgumentList $scf.SessionHandle




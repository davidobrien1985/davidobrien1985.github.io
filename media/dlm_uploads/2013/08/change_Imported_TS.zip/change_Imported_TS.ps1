﻿$Sequence = $null
[string]$SourceSequence = ""
Set-Location PR1:\

$SourceSequence = (Get-CMTaskSequence -Name "Deploy_Win8").Sequence
#$SourceSequence
$SourceSequence = $SourceSequence.Replace("PR1","SPG")

#[xml]$SourceSequence = $SourceSequence.sequence

#$Sequence = ([WmiClass]"ROOT\SMS\site_PR1:SMS_TaskSequencePackage").ImportSequence('$($SourceSequence)').TaskSequence


$Class = "SMS_TaskSequencePackage"
$Method = "ImportSequence"

$MC = [WmiClass]"ROOT\SMS\site_PR1:$Class"
$InParams = $mc.psbase.GetMethodParameters($Method)
$InParams.SequenceXML = $SourceSequence

"Calling SMS_TaskSequencePackage. : ImportSequence with Parameters :"
$inparams.PSBase.properties | select name,Value | format-Table

$Sequence = $mc.PSBase.InvokeMethod($Method, $inParams, $Null)




# create the new Task Sequence Package object
$EmptySequence = ([WmiClass]"ROOT\SMS\site_PR1:SMS_TaskSequencePackage").CreateInstance()
$EmptySequence.Name = "NewTS1"
$EmptySequence.Description = "New Task Sequence"
$EmptySequence.Category = "OSD"


# commit the new Task Sequence
([WmiClass]"ROOT\SMS\site_PR1:SMS_TaskSequencePackage").SetSequence($EmptySequence,$Sequence.TaskSequence)
﻿$Step = $Null
$Sequence = $Null
$TaskSequence = $Null
$SiteCode = "PR1"

$Class = "SMS_TaskSequencePackage"
$Method = "GetSequence"

$InParams = ([WmiClass]"ROOT\SMS\site_$($SiteCode):SMS_TaskSequencePackage").psbase.GetMethodParameters($Method)
$TaskSequence = Get-WmiObject -Class $Class -Namespace root\sms\site_$SiteCode -Filter "Name = 'Deploy_Win8'"

$InParams.TaskSequencePackage = $TaskSequence

$SourceSequence = ([WmiClass]"ROOT\SMS\site_$($SiteCode):SMS_TaskSequencePackage").PSBase.InvokeMethod($Method, $inParams, $Null)

[array]$Steps = @()
foreach ($Step in $SourceSequence.TaskSequence.Steps.Steps)
    {
        $Steps += $Step              
    }

$Sequence = ([WmiClass]"ROOT\SMS\site_$($SiteCode):SMS_TaskSequencePackage").ImportSequence('<sequence version="3.00"/>').TaskSequence

$EmptySequence = ([WmiClass]"ROOT\SMS\site_$($SiteCode):SMS_TaskSequencePackage").CreateInstance()
$EmptySequence.Name = "NewTS0"

$TaskSequence = Get-WmiObject -Class SMS_TaskSequencePackage -Namespace root\sms\site_$SiteCode -Filter "Name = 'NewTS0'"

$InParams.TaskSequencePackage = $TaskSequence

$output = ([WmiClass]"ROOT\SMS\site_$($SiteCode):SMS_TaskSequencePackage").PSBase.InvokeMethod($Method, $inParams, $Null)
$Sequence = $output.TaskSequence

$Group = $Null
$Group = ([WmiClass]"ROOT\SMS\site_$($SiteCode):SMS_TaskSequence_Group").CreateInstance()
$Group.name = "Gruppe1"
$Group.Description = "Desc"
$Group.Enabled = $true
$Group.ContinueOnError = $false

$array = @()
$array += $Steps

$NewSequence = ([WmiClass]"ROOT\SMS\site_$($SiteCode):$($Class)").SetSequence($EmptySequence,$Sequence)
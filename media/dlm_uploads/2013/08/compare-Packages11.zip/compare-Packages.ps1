﻿param (
[switch]$RefreshIfOlder,
[string]$ManagementPoint,
[string]$SiteCode
)

$Packages = Get-WmiObject -ComputerName $ManagementPoint -Namespace root\sms\site_$($SiteCode) -Class SMS_Package -filter "Name like '%'"

foreach ($Pkg in $Packages)
    {
      $DistributionPoints = $null
      [array]$DistributionPoints = Get-WmiObject -ComputerName $ManagementPoint -Namespace "root\sms\site_$($SiteCode)" -Class SMS_DistributionPoint -filter ("packageid ='$($Pkg.PackageID)'")

      if ($DistributionPoints) 
        {
            Write-Host "$($Pkg.Name) found on $($DistributionPoints.count) DPs" 
            foreach ($DP in $DistributionPoints)
                { 
                    if ( $DP.ServerNALPath -Match "\\\\([^\\]+)" ) 
                        {
                            $Server = $matches[1]
                            $URL = "http://" + $Server + '/SMS_DP_SMSPKG$/' + $Pkg.PackageID + '/ruv_isis.ini'
                            $Request = [system.Net.WebRequest]::Create($URL)
                            $Request.UseDefaultCredentials = $true
                            $Response = $Request.GetResponse()
                           
                        }
                    $PkgLastWriteTime = (Get-ItemProperty -Path (Join-Path "$($Pkg.PkgSourcePath)" "ruv_isis.ini")).LastWriteTime
                    if ((New-TimeSpan -Start $Response.LastModified -End $PkgLastWriteTime).Milliseconds -gt 1000) 
                        { 
                            Write-Host "$($Pkg.Name) source on DP is older than in file system."
                            if ($RefreshIfOlder)
                                {
                                    Write-Host "Refreshing Package on $($Server)"
                                    $DP.RefreshNow = $true
                                    $DP.Put()
                                    $Pkg.Name + " refreshed on " + ($DP.ServerNALPath).split("\")[2]
                                }
                        } 
                    else 
                        {
                            Write-Host "No need to refresh $($Pkg.Name) on DP."
                            $Pkg.Name + " not refreshed on " + ($DP.ServerNALPath).split("\")[2]
                        }
                }
        } 
      else 
          {
            $Pkg.Name + " missing"
          }
    }
    
$Response.Close()
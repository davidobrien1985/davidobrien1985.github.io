﻿# this script needs to run in a x86 shell, but we need to access the x64 reg-hive to get the AdminConsole install directory
        $Hive = "LocalMachine"
        $ServerName = "localhost"
        $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]$Hive,$ServerName,[Microsoft.Win32.RegistryView]::Registry64)

        $Subkeys = $reg.OpenSubKey('SOFTWARE\Microsoft\SMS\Setup\')

        $AdminConsoleDirectory = $Subkeys.GetValue('UI Installation Directory')

        #Import the CM12 Powershell cmdlets
        Import-Module "$($AdminConsoleDirectory)\bin\ConfigurationManager.psd1"
        #CM12 cmdlets need to be run from the CM12 drive
        Set-Location "PR1:"
 
$Updates = @{}
$array = @()
 
$array = Get-Content -Path D:\scripts\updates.txt
 
$array | ForEach-Object {
   $Updates = Get-CMSoftwareUpdate -Name "*$_*" | Select-Object LocalizedDisplayName,isDeployed | Where-Object {$_.isDeployed -eq "True"}
   
    }

$Updates.gethashcode()
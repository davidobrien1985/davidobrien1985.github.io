﻿# add object to Security scope

$Computer = "."
$Class = "SMS_SecuredCategoryMembership"
$Method = "AddMemberships"

$MC = [WmiClass]"\\$Computer\ROOT\SMS\site_PR1:$Class"


$InParams = $mc.psbase.GetMethodParameters($Method)


$InParams.CategoryIDs = "PR100001"
$InParams.ObjectIDs = "PR100011"
$InParams.ObjectTypeIDs = 1

"Calling SMS_SecuredCategoryMembership. : AddMemberships with Parameters :"
$inparams.PSBase.properties | select name,Value | format-Table

$R = $mc.PSBase.InvokeMethod($Method, $inParams, $Null)
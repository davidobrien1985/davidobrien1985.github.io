﻿install-windowsfeature web-server

install-windowsfeature as-web-support

install-windowsfeature application-server

install-windowsfeature web-wmi

install-windowsfeature WDS

install-Windowsfeature RDC

install-Windowsfeature BITS

install-windowsfeature web-net-ext -source d:\sources\sxs\

install-windowsfeature NET-HTTP-Activation

install-windowsfeature NET-NON-HTTP-Activ

install-windowsfeature web-asp

#Install-WindowsFeature -Name UpdateServices, UpdateServices-Ui

#& 'C:\Program Files\Update Services\Tools\WsusUtil.exe' postinstall contentdir=C:\WSUS

New-NetFirewallRule -DisplayName "SQL Ports" -Description "SQL ports used by ConfigMgr" -LocalPort 1433,4022 -Protocol TCP -Profile any -Enabled True


New-NetFirewallRule -DisplayName "SQL Ports" -Description "SQL ports used by ConfigMgr" -LocalPort 4022 -Protocol TCP -Profile any -Direction Outbound -Enabled True
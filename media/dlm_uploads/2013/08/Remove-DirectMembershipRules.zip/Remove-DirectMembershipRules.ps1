﻿[CmdletBinding()]
param (
[string]$SiteCode,
[string]$CollectionID
)

if (-not [Environment]::Is64BitProcess)
    {

        # this script needs to run in a x86 shell, but we need to access the x64 reg-hive to get the AdminConsole install directory
        $Hive = "LocalMachine"
        $ServerName = "localhost"
        $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]$Hive,$ServerName,[Microsoft.Win32.RegistryView]::Registry64)

        $Subkeys = $reg.OpenSubKey('SOFTWARE\Microsoft\SMS\Setup\')

        $AdminConsoleDirectory = $Subkeys.GetValue('UI Installation Directory')

        #Import the CM12 Powershell cmdlets
        Import-Module "$($AdminConsoleDirectory)\bin\ConfigurationManager.psd1"
        #CM12 cmdlets need to be run from the CM12 drive
        Set-Location "$($SiteCode):"

        $members = (Get-WmiObject SMS_CollectionMember_a -Namespace root\SMS\Site_$($SiteCode) | where {$_.CollectionID -eq "$($CollectionID)"}).Name

        foreach ($member in $members)
            {
                Remove-CMDeviceCollectionDirectMembershipRule -CollectionID $CollectionID -ResourceName $member -force
            }
    }
else
    {
        Write-Error "This Script needs to be executed in a 32-bit Powershell"
        exit 1
    }       
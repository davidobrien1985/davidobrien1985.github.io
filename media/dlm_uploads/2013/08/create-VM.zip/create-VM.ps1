﻿param(
[string]$VMName
)

$username = "sepago\dobrien"
$password = "Jockthedog2005"
$cred = New-Object System.Management.Automation.PSCredential -ArgumentList @($username,(ConvertTo-SecureString -String $password -AsPlainText -Force))

#Enable-WSManCredSSP -Role Client -DelegateComputer *.sepago.de -force

$session = New-PSSession -ComputerName nb-dobrien.sepago.de -Credential $cred

Invoke-Command -session $session -ArgumentList $VMName -ScriptBlock {


Function create-MAC
    {
        $Randomizer = New-Object System.Random
        $RandomMac = ''
        ForEach ($Number in 1..6) 
            {
                $r = $Randomizer.Next(16,255)
                $Digit = [Convert]::ToString($r,16)
                $RandomMac += $Digit + ':'
            }
        return "00:15:5d:"+$RandomMac.Substring(9,8)

    }


$MAC = create-MAC

$VHD = New-VHD -Dynamic -SizeBytes 20GB -Path "E:\VMs\$($args[0])\$($args[0]).vhdx"

New-VM -Name $args[0] -SwitchName "Internal" -MemoryStartupBytes 2GB -VHDPath $VHD.Path -Path "E:\VMs" -BootDevice LegacyNetworkAdapter

Get-VM -Name $args[0] | Set-VMNetworkAdapter -StaticMacAddress $MAC


}

Remove-PSSession -Session $session
﻿[CmdletBinding( SupportsShouldProcess = $False, ConfirmImpact = "None", DefaultParameterSetName = "" ) ]
param(
[string]$SiteCode,
 [ValidateScript({Test-Path $(Split-Path $_) -PathType 'Container'})] 
 [string]$Path
)

#Set-Location \\srv1\sources\Tools\scripts

[xml]$Applications = Get-Content $Path

Import-Module ($env:SMS_ADMIN_UI_PATH.Substring(0,$env:SMS_ADMIN_UI_PATH.Length – 5) + '\ConfigurationManager.psd1') | Out-Null

#CM12 cmdlets need to be run from the CM12 drive
Set-Location "$($SiteCode):" | Out-Null
if (-not (Get-PSDrive -Name $SiteCode))
    {
        Write-Error "There was a problem loading the Configuration Manager powershell module and accessing the site's PSDrive."
        exit 1
    }

foreach ($App in $Applications.Applications.Application)
    {
        if ($App.AutoInstall)
            {
                $NewApp = New-CMApplication -Name "$($App.Name)" -Description "$($App.Description)" -SoftwareVersion "$($App.SoftwareVersion)" -AutoInstall $true
            }
        else
            {
                $NewApp = New-CMApplication -Name "$($App.Name)" -Description "$($App.Description)" -SoftwareVersion "$($App.SoftwareVersion)"
            }

        foreach ($DeploymentType in $App.DeploymentTypes)
            {      
                if ($DeploymentType.DeploymentType.MsiInstaller)
                    {
                        "Adding DT for MSI Installer"
                        Add-CMDeploymentType -ApplicationName "$($NewApp.LocalizedDisplayName)" -InstallationFileLocation "$($DeploymentType.DeploymentType.InstallationFileLocation)" -MsiInstaller -AutoIdentifyFromInstallationFile -ForceForUnknownPublisher $true
                    }
                if ($DeploymentType.DeploymentType.ScriptInstaller)
                    {
                        "Adding DT for Script Installer"
                        [string]$ContentLocation = ($DeploymentType.DeploymentType.ContentLocation)
                        $ContentLocation = $ContentLocation.Trim()
                        Add-CMDeploymentType -ApplicationName "$($NewApp.LocalizedDisplayName)" -ScriptInstaller -DeploymentTypeName "$($DeploymentType.DeploymentType.DeploymentTypeName)" -InstallationProgram "$($DeploymentType.DeploymentType.InstallationProgram)" -InstallationBehaviorType "$($DeploymentType.DeploymentType.InstallationBehaviorType)" -LogonRequirementType "$($DeploymentType.DeploymentType.LogonRequirementType)" -ContentLocation "$($ContentLocation)" -ManualSpecifyDeploymentType -DetectDeploymentTypeByCustomScript -ScriptType Powershell -ScriptContent "$($env:computername)"
                    }
                else
                    {
                        "There's no further deployment type defined."
                    }
            }
    }

Set-Location C:\
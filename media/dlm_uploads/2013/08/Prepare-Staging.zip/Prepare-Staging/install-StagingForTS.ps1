﻿param ($SMSProvider)Function Get-SiteCode
{
    $wqlQuery = “SELECT * FROM SMS_ProviderLocation”
    $a = Get-WmiObject -Query $wqlQuery -Namespace “root\sms” -ComputerName $SMSProvider
    $a | ForEach-Object {
        if($_.ProviderForLocalSite)
            {
                $script:SiteCode = $_.SiteCode
            }
    }
return $SiteCode
}Function Create-ParentFolder($ParentFolder)    {	    $CollectionFolderArgs = @{	    Name = $ParentFolder;	    ObjectType = "20";	    ParentContainerNodeid = "0"	    }	    Set-WmiInstance -Class SMS_ObjectContainerNode -arguments $CollectionFolderArgs -namespace "root\SMS\Site_$SiteCode" -ComputerName $SMSProvider | Out-Null        [int]$script:ParentFolderID = (Get-WmiObject -Class SMS_ObjectContainerNode -Namespace root\sms\site_$SiteCode -Filter "ObjectType = '20' and Name = 'Staging'" -ComputerName $SMSProvider).ContainerNodeID    }Function Create-ChildFolder($Stage)    {	    $CollectionFolderArgs = @{	    Name = $Stage;	    ObjectType = "20";	    ParentContainerNodeid = "$($ParentFolderID)"	    }	    Set-WmiInstance -Class SMS_ObjectContainerNode -arguments $CollectionFolderArgs -namespace "root\SMS\Site_$SiteCode" -ComputerName $SMSProvider | Out-Null    }$scriptDirectory = Split-Path $myInvocation.MyCommand.Path$Loc = Get-Location $SiteCode = Get-SiteCode#Import the CM12 Powershell cmdlets
if (-not (Test-Path -Path $SiteCode))
    {
        Import-Module ($env:SMS_ADMIN_UI_PATH.Substring(0,$env:SMS_ADMIN_UI_PATH.Length – 5) + '\ConfigurationManager.psd1') | Out-Null
    }
#CM12 cmdlets need to be run from the CM12 drive
Set-Location "$($SiteCode):" | Out-Null
if (-not (Get-PSDrive -Name $SiteCode))
    {
        exit 1
    }$ParentFolder = "Staging"$Stages = @("Development","Quality","Production")Create-ParentFolder $ParentFolderforeach ($Stage in $Stages)    {        Create-ChildFolder $Stage        New-CMSecurityScope -Name $Stage -Description "This Security Scope represents the $($Stage) stage." | Out-Null    }Set-Location $Loc | Out-Null$Scripts = Get-ChildItem "$(Join-Path $scriptDirectory Scripts)" -Recurseif (-not (Test-Path (Join-Path ${env:ProgramFiles(x86)} CM12ConsoleExtensions)))    {        New-Item -Path $(Join-Path ${env:ProgramFiles(x86)} CM12ConsoleExtensions) -ItemType Directory | Out-Null    }foreach ($Script in $Scripts)    {        Copy-Item $Script.FullName -Destination $(Join-Path ${env:ProgramFiles(x86)} CM12ConsoleExtensions) -Force | Out-Null    }Copy-Item .\Extensions -Destination (Join-Path ($env:SMS_ADMIN_UI_PATH.Substring(0,$env:SMS_ADMIN_UI_PATH.Length – 8)) XMLStorage) -Recurse -ErrorAction SilentlyContinue
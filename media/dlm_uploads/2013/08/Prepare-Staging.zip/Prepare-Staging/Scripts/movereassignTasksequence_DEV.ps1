﻿param (
$TaskSequence = $args[0],
$Server= $args[1]
)


$SMSProvider = $Server

Function Get-SiteCode
{
    $wqlQuery = “SELECT * FROM SMS_ProviderLocation”
    $a = Get-WmiObject -Query $wqlQuery -Namespace “root\sms” -ComputerName $SMSProvider
    $a | ForEach-Object {
        if($_.ProviderForLocalSite)
            {
                $script:SiteCode = $_.SiteCode
            }
    }
return $SiteCode
}

function move-TaskSequence {

[int]$ObjectID = 20
[int]$SourceFolder = (Get-WmiObject -Class SMS_ObjectContainerItem -Namespace root\sms\site_$SiteCode -Filter "InstanceKey = '$($TaskSequence)'" -ComputerName $SMSProvider).ContainerNodeID
[int]$TargetFolder = (Get-WmiObject -Class SMS_ObjectContainerNode -Namespace root\sms\site_$SiteCode -Filter "ObjectType = '20' and Name = 'Development'" -ComputerName $SMSProvider).ContainerNodeID

$Parameters = ([wmiclass]"\\$($SMSProvider)\root\SMS\Site_$($SiteCode):SMS_ObjectContainerItem").psbase.GetMethodParameters("MoveMembers")

$Parameters.ObjectType = $ObjectID
$Parameters.ContainerNodeID = $SourceFolder
$Parameters.TargetContainerNodeID = $TargetFolder
$Parameters.InstanceKeys = $TaskSequence
([wmiclass]"\\$($SMSProvider)\root\SMS\Site_$($SiteCode):SMS_ObjectContainerItem").psbase.InvokeMethod("MoveMembers",$Parameters,$null) | Out-Null
}

$SiteCode = Get-SiteCode
#Import the CM12 Powershell cmdlets
if (-not (Test-Path -Path $SiteCode))
    {
        Import-Module ($env:SMS_ADMIN_UI_PATH.Substring(0,$env:SMS_ADMIN_UI_PATH.Length – 5) + '\ConfigurationManager.psd1') | Out-Null
    }
#CM12 cmdlets need to be run from the CM12 drive
Set-Location "$($SiteCode):" | Out-Null
if (-not (Get-PSDrive -Name $SiteCode))
    {
        exit 1
    }

move-TaskSequence 
$Scopes = (Get-CMTaskSequence -TaskSequencePackageId $TaskSequence).SecuredScopeNames
Set-CMTaskSequence -SecurityScopeAction AddMembership -SecurityScopeName Development -TaskSequencePackageId $TaskSequence

foreach ($Scope in $Scopes)
    {
        Set-CMTaskSequence -SecurityScopeAction RemoveMembership -SecurityScopeName $Scope -TaskSequencePackageId $TaskSequence
    }

[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") | Out-Null
[System.Windows.Forms.MessageBox]::Show("Task Sequence has been moved.")
﻿param (
[string]$DBServerName,
[string]$DBServerInstance,
[string]$WSUSContentPath
)

if (-not (Get-WindowsFeature -Name UpdateServices).Installed -eq $true)
    {
        Install-WindowsFeature -Name UpdateServices-DB, UpdateServices-Ui -IncludeManagementTools -LogPath C:\Windows\System32\LogFiles\WSUSInstall.log
        $command = ". `"$env:ProgramFiles\Update Services\Tools\WsusUtil.exe`" PostInstall SQL_INSTANCE_NAME=$DBServerName\$DBServerInstance CONTENT_DIR=$WSUSContentPath"
        Invoke-Expression -Command $command 
        Write-Host "WSUS installed and configured"
    }
else
    {
        Write-Host "WSUS is already installed and configured"

    }
﻿[CmdletBinding()]

param(
[string]$SiteCode,
[Parameter(ParameterSetName='ID',Position=0)]
[string]$CollectionID,
[Parameter(ParameterSetName='Name',Position=0)]
[string]$CollectionName
)


if ($CollectionID) 
    {
        $Advertisement = Get-WmiObject -Class SMS_Advertisement -Namespace root\sms\site_$($SiteCode) | Where-Object {$_.CollectionID -eq "$($CollectionID)"}
        if (($Advertisement -eq $null) -or ($Advertisement -eq ""))
            {
                Write-Error "Could not find any deployment on the given collection"
                exit 1
            }
        Write-Verbose "Will delete the Deployment $($Collection).AdvertisementName"
        $Advertisement | Remove-WmiObject
        if ($?)
            {
                Write-Verbose "Successfully deleted the deployment"
            }
        else 
            {
                Write-Error -Message "There was an error deleting the deployment"
            }
    }

else
    {
        Write-Verbose "Enumerating the CollectionID"
        $CollectionID = (Get-WmiObject -Class SMS_Collection -Namespace root\sms\site_$($SiteCode) | Where-Object {$_.Name -eq "$($CollectionName)"}).CollectionID
        
        if (($CollectionID -eq $null) -or ($CollectionID -eq ""))
            {
                Write-Error "The given Collection could not be found"
                exit 1
            }

        $Advertisement = Get-WmiObject -Class SMS_Advertisement -Namespace root\sms\site_$($SiteCode) | Where-Object {$_.CollectionID -eq "$($CollectionID)"}
        
        if (($Advertisement -eq $null) -or ($Advertisement -eq ""))
            {
                Write-Error "Could not find any deployment on the given collection"
                exit 1
            }
        
        Write-Verbose "Will delete the Deployment $($Advertisement.AdvertisementName)"
        $Advertisement | Remove-WmiObject
        if ($?)
            {
                Write-Verbose "Successfully deleted the deployment"
            }
        else 
            {
                Write-Error -Message "There was an error deleting the deployment"
            }
    }
    